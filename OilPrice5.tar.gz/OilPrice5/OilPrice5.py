# This version is updated getting terminal size in other OS
# and also separated modules
from Package import getsizeterminal
from Package import function
cal = ['', 'LITER -> MONEY', 'MONEY -> LITER']


if __name__ == '__main__':

    check = True
    while check:

        # Information about program
        sizex, sizey = getsizeterminal.get_terminal_size()
        print(sizex, sizey)
        function.home(sizex, sizey)
        input()

        # Update data from website
        name = ['none']
        price = [0]
        name, price = function.update_price(name, price)

        # print out menu of petrol type and input oil type
        oil_type = n = k = m = c = ''
        while not (k.isnumeric() and int(k) in range(1, len(name))):
            function.menu(sizex, sizey, name, price)
            k = input()
        k = int(k)

        set = [str(name[k]) + ' - price : ' + str(price[k]) + " baht/l",
               "Please choose the method calculation:",
               "1. " + cal[1], "2. " + cal[2]]
        # Choose calculation option and kind of petrol
        while not (n.isnumeric() and int(n) in [1, 2]):
            function.ask(sizex, sizey, set)
            n = input()
        n = int(n)

        set = [str(name[k]) + ' - price : ' + str(price[k]) + " baht/l",
               "You chose method calculation: " + cal[n],
               "Please enter the number of LITER or MONEY"]
        # Calculate total liters
        while not m.isnumeric():
            function.ask(sizex, sizey, set)
            m = input()
        m = float(m)
        if n == 2:
            res = round(m / price[k], 2)
            set = [str(name[k]) + '- price : ' + str(price[k]) + " baht/l",
                   "The number of liters: " + str(res) + " l",
                   "You pay: " + str(m) + " baht",
                   "What do you want to do next?",
                   "1. Exit program", "2. Start new calculation"]
        # Calculate total money
        else:
            res = round(m * price[k], 2)
            set = [str(name[k]) + ' - price : ' + str(price[k]) + " baht/l",
                   "The number of liters: " + str(m) + " l",
                   "You pay: " + str(res) + " baht",
                   "What do you want to do next?",
                   "1. Exit program", "2. Start new calculation"]

        # aking for comeback main menu or exit program
        while not (c.isnumeric() and int(c) in [1, 2]):
            function.ask(sizex, sizey, set)
            c = input()
        if c == '1':
            check = False
            print()
