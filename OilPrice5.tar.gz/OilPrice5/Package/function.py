import os
import platform
from zeep import Client
from lxml import etree
import subprocess as sp

client = Client('https://www.pttor.com/OilPrice.asmx?WSDL')
cal = ['', 'LITER -> MONEY', 'MONEY -> LITER']

sp.call('cls', shell=True)

sp.run('', shell=True)


# get pllatform of OS and create command
def get_platform():
    current_os = platform.system()
    cmd = ''
    if current_os == 'Windows':
        cmd = 'cls'
    elif current_os in ['Linux', 'Darwin']:
        cmd = 'clear'
    return cmd

command = get_platform()


# Print welcome screen with information of program
def home(sizex, sizey):
    os.system(command)
    row = sizey // 2 - 3
    col = sizex - 1
    print("*" * (col))
    for i in range(row):
        print("*" + ' ' * (col - 2) + '*')
    print('*' + ' ' * (col // 2 - 10) + "PETROL SALE SYSTEM", end='')
    print(' ' * (col - col // 2 - 10) + '*')
    print('*' + ' ' * (col // 2 - 12) + 'Author: Nhan Le Thi Thanh', end='')
    print(' ' * (col - col // 2 - 15) + '*')
    print('*' + ' ' * (col // 2 - 11) + 'Published at 09/01/2020', end='')
    print(' ' * (col - col // 2 - 14) + '*')
    print("*" + ' ' * (col - 2) + '*')
    print("*" + ' ' * (col - 2) + '*')
    print("*" + ' ' * (col - 2) + '*')
    print("*" + ' ' * (col // 2 - 25) + "WELCOME TO OUR SYSTEM!", end='')
    print(' PLEASE PRESS ANY KEY TO CONTINUE...\0337', end='')
    print(' ' * (col - col // 2 - 35) + "*")
    for i in range(row - 3):
        print("*" + ' ' * (col - 2) + '*')
    print("*" * (col) + '\0338', end='')


# update data from website of ptt
def update_price(name, price):
    result = client.service.CurrentOilPrice(Language="en")
    root = etree.fromstring(result)
    for i in range(len(root)):
        if len(root[i]) == 3:
            name.append(root[i][1].text)
            price.append(float(root[i][2].text))
    return name, price


# print menu of oil type and price of each one
def menu(sizex, sizey, name, price):
    os.system(command)
    row = sizey // 2 - 1
    col = sizex - 1
    val = col // 2
    print("*" * (col))
    for i in range(0, row - len(name) // 2 - 1):
        print("*" + ' ' * (col - 2) + '*')
    print('*' + ' ' * (val - 2) + 'MENU' + ' ' * (col - val - 4) + '*')
    for i in range(1, len(name)):
        s = str(i) + '. ' + name[i] + ' : ' + str(price[i]) + ' BAHT'
        print('*' + (val - 10) * ' ' + s, end='')
        print((col - len(s) - val + 8) * ' ' + '*')
    for i in range(0, row - len(name) // 2):
        print("*" + ' ' * (col - 2) + '*')
    print("*" + ' ' * (val - 17), end='')
    print("Please choose the kind of petrol: \0337", end='')
    print(' ' * (col - val - 19) + "*" + "\n" + "*" * col + '\0338', end='')


# print selection of customer and asking information
def ask(x, y, set):
    os.system(command)
    col = x - 1
    row = (y - len(set)) // 2 - 1
    print("*" * col)
    for i in range(row):
        print("*" + ' ' * (col - 2) + "*")
    val = len(set)
    for i in set:
        print("*" + ' ' * (col // 2 - len(i) // 2) + i, end='')
        print(' ' * (col - (col // 2 - len(i) // 2) - len(i) - 2) + "*")
    for i in range(row - 1):
        print("*" + ' ' * (col - 2) + "*")
    print("*" + ' ' * (col // 2 - 12), end='')
    print("Please enter the number: \0337", end='')
    print(' ' * (col - (col // 2) - 15) + "*\n", end='')
    print("*" * col + '\0338', end='')
